# WHILE Transpiler Plugin

Plugin for WHILE transpiler that finds snippets of code that are logically connected.

